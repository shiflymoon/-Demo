//
//  PAThread.m
//  ThreadTest
//
//  Created by 史贵岭 on 2018/4/18.
//  Copyright © 2018年 史贵岭. All rights reserved.
//

#import "PAThread.h"

@interface PATObj :NSObject
@property (nonatomic,copy) NSString *name;
@property (nonatomic,strong) NSNumber *number;
@property (nonatomic,strong) PATObj *pObj;
@end

@implementation PATObj
+(instancetype) instanceObj{
    return [[PATObj alloc] init];
}
@end

@implementation PAThread

-(void) main{
    //1.oc采用引用计数管理内存
    //2.只要线程中，即使不添加自动释放池临时对象不被其他线程强引用，在线程结束后，内存都能释放，不存在所谓内存泄露
    //3.自动释放池在其销毁，或者pop出对象调用其releas方法
    //4.如果线程runloop运行后，都会自动创建一个全局自动释放池，在RunLoop每次循环尝试pop出未被强引用对象，并调用其release
    //5.添加到自动释放池，对象引用计数不会+1，但对象会延迟释放，如果是全局自动释放池，下个runloop循环
    //6.ARC在编译期间自动补上retain、release、autorelease
    //8.适当使用自动释放池，能较有效控制内存峰值
    
    NSMutableArray *dataArray = [NSMutableArray array];
    for(NSInteger i = 0 ;i<1000000;i++){
        PATObj *obj = [PATObj new];
        obj.name = [[NSString alloc] initWithFormat:@"%@",@(i)];
        obj.number = [[NSNumber alloc] initWithLong:i];
        obj.pObj = [PATObj instanceObj];
        [dataArray addObject:obj];
    }
    
    NSLog(@"end");
    
}
@end
