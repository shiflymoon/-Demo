//
//  ViewController.m
//  ThreadTest
//
//  Created by 史贵岭 on 2018/4/18.
//  Copyright © 2018年 史贵岭. All rights reserved.
//

#import "ViewController.h"
#import "PAThread.h"
#import "PAMRCThread.h"
#import "PARunLoopRightThread.h"
#import "PATimerThread.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
 //   [self startThread];//arc自动释放池
//     [self startMRCThread];//mrc自动释放池
   [self startRunLoopThread];//子线程runloop运行任务
   // [self startPATimer];//测试定时器精度
}

#pragma mark - Private
-(void) startThread{
    PAThread *t =[PAThread new];
    [t start];
}

-(void) startMRCThread{
    PAMRCThread *t = [PAMRCThread new];
    [t start];
}

-(void) startPATimer{
    PATimerThread *t = [PATimerThread new];
    [t start];
}

-(void) startRunLoopThread{
    PARunLoopRightThread *thread = [PARunLoopRightThread new];
    [thread start];
    
   [thread runTaskInThreadTarget:self action:@selector(_PARunLoopTask)];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [thread runTaskInThreadTarget:self action:@selector(_PARunLoopTask2)];
    });

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(14.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [thread stopPAThread];
    });
   
}

-(void) _PARunLoopTask{
    NSLog(@"Task One");
}

-(void) _PARunLoopTask2{
    NSLog(@"Task Two");
}


@end
