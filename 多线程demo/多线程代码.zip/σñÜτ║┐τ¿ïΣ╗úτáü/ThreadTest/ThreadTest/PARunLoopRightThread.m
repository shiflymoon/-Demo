//
//  PARunLoopRightThread.m
//  ThreadTest
//
//  Created by 史贵岭 on 2018/4/19.
//  Copyright © 2018年 史贵岭. All rights reserved.
//

#import "PARunLoopRightThread.h"
@interface PARunLoopRightThread()
{
    BOOL _exitThread;
}
@end
@implementation PARunLoopRightThread

#pragma mark - Public
-(void) runTaskInThreadTarget:(id) target action:(SEL) taskSelector{
    if(!taskSelector || !target || ![target respondsToSelector:taskSelector]) {
        return;
    }
    
    //只有输入源才可以唤醒runloop，并执行任务
    [target performSelector:taskSelector onThread:self withObject:nil waitUntilDone:NO];
}

-(void) stopPAThread
{
    [self performSelector:@selector(_PAExitThread) onThread:self withObject:nil waitUntilDone:NO];
}

#pragma mark - Thread Method
-(void) main{
    //通过perform onThread构造输入源，Run Loop必须存在过输入源才能正常启动
    //通过定时周期无限大的定时器也可以作为输入源
    [self performSelector:@selector(doNothing) onThread:self withObject:nil waitUntilDone:NO];
    
    while (!_exitThread) {
        //NSRunLoopCommonModes不是合法mode，只是个占位符
        [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];//runloop只运行一次
      //  NSLog(@"RunLoop退出了");
    }
    NSLog(@"线程退出了");
}

#pragma mark - Private
-(void) doNothing{
    
}

-(void) _PAExitThread{
    _exitThread = YES;
}
@end
