//
//  PATimerThread.m
//  ThreadTest
//
//  Created by 史贵岭 on 2018/4/19.
//  Copyright © 2018年 史贵岭. All rights reserved.
//

#import "PATimerThread.h"

@implementation PATimerThread
-(void) main{
    NSTimer *timer = [NSTimer timerWithTimeInterval:0.00001 target:self selector:@selector(outPut) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
    
    [[NSRunLoop currentRunLoop] run];
}

long long count = 0;
-(void) outPut{
    count++;
    if(count >100000){
        count = 0;
        NSLog(@"----");
    }
  
}
@end
