//
//  NSObject+GCDThreadSafe.h
//  Created by 史贵岭 on 16/8/3.
//  Copyright (c) 2016 史贵岭. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (GCDThreadSafe)

- (id)threadSafe_init;
- (BOOL)threadSafe_QueueSync:(dispatch_block_t) block;
- (BOOL)threadSafe_QueueBarrierAsync:(dispatch_block_t) block;

@end
