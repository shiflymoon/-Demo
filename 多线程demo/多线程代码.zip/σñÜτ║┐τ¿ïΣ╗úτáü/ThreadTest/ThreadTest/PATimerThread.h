//
//  PATimerThread.h
//  ThreadTest
//
//  Created by 史贵岭 on 2018/4/19.
//  Copyright © 2018年 史贵岭. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PATimerThread : NSThread

@end
