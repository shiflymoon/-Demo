//
//  ViewController.m
//  TestThreadLock
//
//  Created by 史贵岭 on 2018/4/23.
//  Copyright © 2018年 史贵岭. All rights reserved.
//

#import "ViewController.h"
#import "MJRefresh.h"

@interface ViewController ()<UITableViewDataSource>
{
    UITableView *_testTableView;
    UIButton *_actionButton;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:[self tTableView]];
    [self.view addSubview:[self actionButton]];
   
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1000;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *rid = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:rid];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:rid];
    }
    cell.textLabel.text = @"test";
    return cell;
}

#pragma mark -Private
-(void) buttonAction:(id)sender{
    NSLog(@"我执行了");
    [self mockSecondaryBlock];
}

-(void) endRefresh{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [_testTableView.mj_header endRefreshing];
    });
}

-(void) mockSecondaryBlock{
    for(int i =0 ;i<64;i++){
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            [self performSelector:@selector(doNothing) onThread:[NSThread currentThread] withObject:nil waitUntilDone:NO];
           
             CFRunLoopRun();
        });
    }
}

-(void) doNothing{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Getter
-(UIButton *) actionButton{
    if(!_actionButton){
        _actionButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _actionButton.frame = CGRectMake(100, 100, 100, 40);
        _actionButton.backgroundColor = [UIColor redColor];
        [_actionButton setTitle:@"执行操作" forState:UIControlStateNormal];
        
        [_actionButton addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _actionButton;
}

-(UITableView *) tTableView{
    if(!_testTableView){
        _testTableView = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain];
        _testTableView.rowHeight = 50;
        
        __weak typeof(self) ws = self;
        _testTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [ws endRefresh];
        }];
        
        _testTableView.dataSource = self;
    }
    return _testTableView;
}



@end
