//
//  TestInlineHook.h
//  libhook
//
//  Created by 吴昕 on 22/02/2017.
//  Copyright © 2017 ChinaNetCenter. All rights reserved.
//

#ifndef TestInlineHook_h
#define TestInlineHook_h

#include <stdio.h>

void test_inline_hook();

#endif /* TestInlineHook_h */
