//
//  libhook.h
//  libhook
//
//  Created by 吴昕 on 22/02/2017.
//  Copyright © 2017 ChinaNetCenter. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface libhook : NSObject

@end
